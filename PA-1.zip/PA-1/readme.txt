
	//Link to the site:
	http://circinus-6.ics.uci.edu:8080/project1/index.html

//References

	
	//How to Top Nav
	https://www.w3schools.com/howto/howto_js_topnav.asp

	//The Joy of CSS Grid - Build 3 Beautifully Simple Responsive Layouts
	https://www.youtube.com/watch?v=705XCEruZFs

	//Search Bar
	https://www.w3schools.com/howto/howto_css_fullscreen_search.asp

	//A step-by-step guide to getting started with HTML tables
	https://medium.com/free-code-camp/a-step-by-step-guide-to-getting-started-with-html-tables-7f43b18f962b

	//How To Create a Card
	https://www.w3schools.com/howto/howto_css_cards.asp

	//How TO - Parallax Scrolling
	https://www.w3schools.com/howto/howto_css_parallax.asp

	//game controller icon
	https://fontawesome.com/icons/gamepad?style=solid

	//marquee //end up removing date and time
	http://jsfiddle.net/n2XB6/63/

	//JavaScript - Form Validation
	https://www.tutorialspoint.com/javascript/javascript_form_validations.htm

	//JavaScript: HTML Form - email validation
	https://www.w3resource.com/javascript/form/email-validation.php

	//Automatically open default email client and pre-populate content
	https://stackoverflow.com/questions/13231125/automatically-open-default-email-client-and-pre-populate-content