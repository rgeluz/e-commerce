//Group members	
	Roman Geluz 
	ID# 21849143

	Rishi Shah
	ID# 12474679
	
	Michael Hernandez
	ID# 68363688
	
	Haitao Ye
	ID# 21497606

	//Link to the site:
	http://circinus-6.ics.uci.edu:8080/project1/index.html
	
//About the site
	We have a cool introducing home page where the user must click the floating bar to enter the actual e-commerce page.
	The products page shows the overview about our products, along with the general categories of merchandise that 
	are being selling.
	The top navigation bar also provide a about drop down button, where our team, company and contact pages are located.
	The company page gives the overview about the site, and team page gives relative information about the team
	and also the student ids. The contact page also shows a email option that could send contact request.
	From the product page the user can choose any category he or she is interested and click on the picture 
	to enter the according product detail page, 
	the category cards have hover effect which zooms out when a mouse is being hovered on.
	The detailed page shows all basic information about the product, the user can click on the small pictures to 
	enlarge them.
	The ordering form can also be found on the product detail page, it checks the must fill-in fields and send a 
	email once all checks are passed. 
	
//References

	
	//How to Top Nav
	https://www.w3schools.com/howto/howto_js_topnav.asp

	//The Joy of CSS Grid - Build 3 Beautifully Simple Responsive Layouts
	https://www.youtube.com/watch?v=705XCEruZFs

	//Search Bar
	https://www.w3schools.com/howto/howto_css_fullscreen_search.asp

	//A step-by-step guide to getting started with HTML tables
	https://medium.com/free-code-camp/a-step-by-step-guide-to-getting-started-with-html-tables-7f43b18f962b

	//How To Create a Card
	https://www.w3schools.com/howto/howto_css_cards.asp

	//How TO - Parallax Scrolling
	https://www.w3schools.com/howto/howto_css_parallax.asp

	//HOW TO - Blurred Background Image
	https://www.w3schools.com/howto/howto_css_blurred_background.asp

	//HOW TO - Meet the team
	https://www.w3schools.com/howto/howto_css_team.asp
	
	//HOW TO - CSS/JS Modal
	https://www.w3schools.com/howto/howto_css_modals.asp
	
	//game controller icon
	https://fontawesome.com/icons/gamepad?style=solid

	//marquee //end up removing date and time
	http://jsfiddle.net/n2XB6/63/

	//JavaScript - Form Validation
	https://www.tutorialspoint.com/javascript/javascript_form_validations.htm

	//JavaScript: HTML Form - email validation
	https://www.w3resource.com/javascript/form/email-validation.php

	//Automatically open default email client and pre-populate content
	https://stackoverflow.com/questions/13231125/automatically-open-default-email-client-and-pre-populate-content